// Same-origin deployment: the frontend calls /api on this Worker.
window.RDS_CONFIG = { API_BASE: "" };
