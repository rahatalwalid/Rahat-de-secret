const API = (window.RDS_CONFIG?.API_BASE || "").replace(/\/+$/,"");
const $ = id => document.getElementById(id);
let currentConversation = null;
let conversations = [];

async function api(path, options={}) {
  const res = await fetch(API + path, { ...options, credentials:"include",
    headers: { "Content-Type":"application/json", ...(options.headers||{}) } });
  let data={}; try{data=await res.json()}catch{}
  if(!res.ok) throw new Error(data.message || data.error || `Request failed (${res.status})`);
  return data;
}
function showApp(on){$("login").classList.toggle("hidden",on);$("app").classList.toggle("hidden",!on);$("logout").classList.toggle("hidden",!on)}
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function item(title,desc,meta=""){return `<div class="item"><strong>${escapeHtml(title)}</strong>${desc?`<div>${escapeHtml(desc)}</div>`:""}${meta?`<small>${escapeHtml(meta)}</small>`:""}</div>`}

async function boot(){
  try{
    const h=await api("/api/health");
    $("providerPill").textContent=h.providerReady?`Free provider: ${h.provider||"ready"}`:"AI paused · no verified free provider";
    $("providerPill").classList.toggle("ready",h.providerReady);
    await api("/api/overview"); showApp(true); await refreshAll();
  }catch(e){showApp(false)}
}
async function refreshOverview(){
  const d=await api("/api/overview");
  $("agentCount").textContent=d.agents;$("projectCount").textContent=d.projects;$("taskCount").textContent=d.queuedTasks;$("chatCount").textContent=d.conversations;
}
async function refreshConversations(){
  const d=await api("/api/conversations"); conversations=d.conversations;
  $("conversationList").innerHTML=conversations.map(c=>`<button class="conversation ${c.id===currentConversation?"active":""}" data-id="${c.id}">${escapeHtml(c.title)}</button>`).join("") || '<div class="empty">No conversations yet.</div>';
  document.querySelectorAll(".conversation").forEach(b=>b.onclick=()=>openConversation(b.dataset.id));
}
async function openConversation(cid){
  currentConversation=cid; const d=await api("/api/conversations/"+cid);
  $("chatMessages").innerHTML=d.messages.map(m=>`<div class="bubble ${m.role}">${escapeHtml(m.content)}</div>`).join("") || '<div class="empty">Say hello.</div>';
  $("chatMessages").scrollTop=$("chatMessages").scrollHeight; await refreshConversations();
}
async function refreshLists(){
  const [a,p,t,m]=await Promise.all([api("/api/agents"),api("/api/projects"),api("/api/tasks"),api("/api/memory")]);
  $("agentList").innerHTML=a.agents.map(x=>item(x.name,x.instructions,x.role+" · "+x.status)).join("")||'<div class="empty">No agents created yet.</div>';
  $("projectList").innerHTML=p.projects.map(x=>item(x.name,x.description,x.status)).join("")||'<div class="empty">No projects yet.</div>';
  $("taskList").innerHTML=t.tasks.map(x=>item(x.title,x.details,x.status+" · approval required")).join("")||'<div class="empty">No queued tasks.</div>';
  $("memoryList").innerHTML=m.items.map(x=>item(x.content,"",new Date(x.created_at).toLocaleString())).join("")||'<div class="empty">No saved memories.</div>';
}
async function refreshAll(){await Promise.all([refreshOverview(),refreshConversations(),refreshLists()])}

$("loginForm").addEventListener("submit",async e=>{
  e.preventDefault();$("loginError").textContent="";
  try{await api("/api/login",{method:"POST",body:JSON.stringify({password:$("password").value})});$("password").value="";await boot()}
  catch(err){$("loginError").textContent=err.message}
});
$("logout").onclick=async()=>{try{await api("/api/logout",{method:"POST"})}finally{showApp(false)}};
$("newChat").onclick=async()=>{
  const d=await api("/api/conversations",{method:"POST",body:JSON.stringify({title:"New conversation"})});
  await openConversation(d.id);await refreshOverview();
};
$("chatForm").onsubmit=async e=>{
  e.preventDefault();const msg=$("chatInput").value.trim();if(!msg)return;
  if(!currentConversation){const d=await api("/api/conversations",{method:"POST",body:JSON.stringify({title:msg.slice(0,42)})});currentConversation=d.id}
  $("chatInput").value="";$("chatStatus").textContent="Saving message…";
  try{
    const d=await api("/api/chat",{method:"POST",body:JSON.stringify({conversationId:currentConversation,message:msg})});
    $("chatStatus").textContent="";await openConversation(currentConversation);
  }catch(err){$("chatStatus").textContent=err.message;await openConversation(currentConversation)}
  await refreshOverview();
};
$("agentForm").onsubmit=async e=>{e.preventDefault();try{await api("/api/agents",{method:"POST",body:JSON.stringify({name:$("agentName").value,role:$("agentRole").value,instructions:$("agentInstructions").value})});e.target.reset();await refreshAll()}catch(x){alert(x.message)}};
$("projectForm").onsubmit=async e=>{e.preventDefault();try{await api("/api/projects",{method:"POST",body:JSON.stringify({name:$("projectName").value,description:$("projectDescription").value})});e.target.reset();await refreshAll()}catch(x){alert(x.message)}};
$("taskForm").onsubmit=async e=>{e.preventDefault();try{await api("/api/tasks",{method:"POST",body:JSON.stringify({title:$("taskTitle").value,details:$("taskDetails").value})});e.target.reset();await refreshAll()}catch(x){alert(x.message)}};
$("memoryForm").onsubmit=async e=>{e.preventDefault();try{await api("/api/memory",{method:"POST",body:JSON.stringify({content:$("memoryContent").value})});e.target.reset();await refreshAll()}catch(x){alert(x.message)}};
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{
  document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));
  document.querySelectorAll(".tabpanel").forEach(x=>x.classList.toggle("hidden",x.id!=="tab-"+b.dataset.tab));
});
boot();
