const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
});
const now = () => new Date().toISOString();
const id = () => crypto.randomUUID();

async function hmac(secret, value) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value));
  return btoa(String.fromCharCode(...new Uint8Array(sig))).replaceAll("+","-").replaceAll("/","_").replaceAll("=","");
}
async function makeSession(env) {
  const payload = btoa(JSON.stringify({ exp: Date.now() + 1000 * 60 * 60 * 24 * 5 }));
  return payload + "." + await hmac(env.SESSION_SECRET, payload);
}
async function validSession(req, env) {
  const raw = (req.headers.get("Cookie") || "").split(";").map(x=>x.trim()).find(x=>x.startsWith("rds_session="));
  if (!raw) return false;
  const token = raw.slice("rds_session=".length), parts = token.split(".");
  if (parts.length !== 2 || !env.SESSION_SECRET) return false;
  if (await hmac(env.SESSION_SECRET, parts[0]) !== parts[1]) return false;
  try { return JSON.parse(atob(parts[0])).exp > Date.now(); } catch { return false; }
}
function cors(req, env) {
  const origin = req.headers.get("Origin");
  const allowed = env.APP_ORIGIN || "";
  const headers = new Headers({
    "Access-Control-Allow-Methods": "GET,POST,DELETE,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Credentials": "true",
    "Vary": "Origin"
  });
  if (origin && origin === allowed) headers.set("Access-Control-Allow-Origin", origin);
  return headers;
}
async function respond(req, env, data, status=200, extra={}) {
  const headers = cors(req, env);
  headers.set("content-type","application/json; charset=utf-8");
  headers.set("cache-control","no-store");
  for (const [k,v] of Object.entries(extra)) headers.set(k,v);
  return new Response(JSON.stringify(data), {status, headers});
}
async function body(req) { try { return await req.json(); } catch { return {}; } }
async function audit(env, action, detail="") {
  await env.DB.prepare("INSERT INTO audit_log (id,action,detail,created_at) VALUES (?,?,?,?)")
    .bind(id(), action, detail, now()).run();
}
async function providerReady(env) {
  return env.FREE_ONLY === "true" &&
    env.AI_FREE_VERIFIED === "true" &&
    !!env.AI_API_KEY && !!env.AI_BASE_URL && !!env.AI_MODEL;
}
async function callModel(env, messages) {
  if (!(await providerReady(env))) throw new Error("NO_VERIFIED_FREE_PROVIDER");
  const base = env.AI_BASE_URL.replace(/\/+$/, "");
  const response = await fetch(base + "/chat/completions", {
    method: "POST",
    headers: { "Authorization": "Bearer " + env.AI_API_KEY, "Content-Type": "application/json" },
    body: JSON.stringify({ model: env.AI_MODEL, messages, temperature: 0.6 })
  });
  if (!response.ok) {
    if (response.status === 402 || response.status === 429 || response.status === 403)
      throw new Error("FREE_PROVIDER_QUOTA_OR_ACCESS_BLOCKED");
    throw new Error("PROVIDER_ERROR_" + response.status);
  }
  const data = await response.json();
  const answer = data?.choices?.[0]?.message?.content;
  if (typeof answer !== "string" || !answer.trim()) throw new Error("EMPTY_MODEL_RESPONSE");
  return answer;
}

export default {
  async fetch(req, env) {
    if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors(req, env) });
    const url = new URL(req.url), path = url.pathname;
    if (!env.DB) return respond(req, env, {error:"Database binding DB is missing"}, 500);

    if (path === "/api/health" && req.method === "GET") {
      return respond(req, env, { app:"Rahat DeSecret", version:"0.1.0", freeOnly: env.FREE_ONLY === "true",
        providerReady: await providerReady(env), provider: env.AI_PROVIDER_NAME || null });
    }

    if (path === "/api/login" && req.method === "POST") {
      const b = await body(req);
      if (!env.OWNER_PASSWORD || !env.SESSION_SECRET) return respond(req, env,{error:"Server auth secrets are not configured"},500);
      if (typeof b.password !== "string" || b.password !== env.OWNER_PASSWORD) {
        await audit(env,"login_failed");
        return respond(req, env,{error:"Incorrect password"},401);
      }
      const token = await makeSession(env);
      await audit(env,"owner_login");
      return respond(req, env,{ok:true},200,{"Set-Cookie":`rds_session=${token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=432000`});
    }

    if (path === "/api/logout" && req.method === "POST") {
      return respond(req, env,{ok:true},200,{"Set-Cookie":"rds_session=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0"});
    }

    if (!(await validSession(req, env))) return respond(req, env,{error:"Authentication required"},401);

    if (path === "/api/overview" && req.method === "GET") {
      const [a,p,t,c] = await Promise.all([
        env.DB.prepare("SELECT COUNT(*) n FROM agents").first(),
        env.DB.prepare("SELECT COUNT(*) n FROM projects").first(),
        env.DB.prepare("SELECT COUNT(*) n FROM tasks WHERE status='queued'").first(),
        env.DB.prepare("SELECT COUNT(*) n FROM conversations").first()
      ]);
      return respond(req, env,{agents:a.n,projects:p.n,queuedTasks:t.n,conversations:c.n,providerReady:await providerReady(env)});
    }

    if (path === "/api/agents" && req.method === "GET") {
      const r = await env.DB.prepare("SELECT * FROM agents ORDER BY created_at DESC").all();
      return respond(req, env,{agents:r.results});
    }
    if (path === "/api/agents" && req.method === "POST") {
      const b=await body(req);
      if (!b.name || !b.role) return respond(req,env,{error:"Name and role are required"},400);
      const agent={id:id(),name:String(b.name).slice(0,60),role:String(b.role).slice(0,80),
        instructions:String(b.instructions||"").slice(0,4000),status:"active",created_at:now()};
      await env.DB.prepare("INSERT INTO agents (id,name,role,instructions,status,created_at) VALUES (?,?,?,?,?,?)")
        .bind(agent.id,agent.name,agent.role,agent.instructions,agent.status,agent.created_at).run();
      await audit(env,"agent_created",agent.name);
      return respond(req,env,{agent},201);
    }

    if (path === "/api/projects" && req.method === "GET") {
      const r=await env.DB.prepare("SELECT * FROM projects ORDER BY updated_at DESC").all();
      return respond(req,env,{projects:r.results});
    }
    if (path === "/api/projects" && req.method === "POST") {
      const b=await body(req);
      if (!b.name) return respond(req,env,{error:"Project name is required"},400);
      const p={id:id(),name:String(b.name).slice(0,100),description:String(b.description||"").slice(0,3000),status:"active",created_at:now(),updated_at:now()};
      await env.DB.prepare("INSERT INTO projects (id,name,description,status,created_at,updated_at) VALUES (?,?,?,?,?,?)")
        .bind(p.id,p.name,p.description,p.status,p.created_at,p.updated_at).run();
      await audit(env,"project_created",p.name);
      return respond(req,env,{project:p},201);
    }

    if (path === "/api/conversations" && req.method === "GET") {
      const r=await env.DB.prepare("SELECT id,title,created_at,updated_at FROM conversations ORDER BY updated_at DESC LIMIT 100").all();
      return respond(req,env,{conversations:r.results});
    }
    if (path === "/api/conversations" && req.method === "POST") {
      const b=await body(req), cid=id(), stamp=now();
      await env.DB.prepare("INSERT INTO conversations (id,title,created_at,updated_at) VALUES (?,?,?,?)")
        .bind(cid,String(b.title||"New conversation").slice(0,120),stamp,stamp).run();
      return respond(req,env,{id:cid,title:b.title||"New conversation"},201);
    }
    const convoMatch=path.match(/^\/api\/conversations\/([a-f0-9-]+)$/i);
    if (convoMatch && req.method === "GET") {
      const c=await env.DB.prepare("SELECT * FROM conversations WHERE id=?").bind(convoMatch[1]).first();
      if (!c) return respond(req,env,{error:"Conversation not found"},404);
      const m=await env.DB.prepare("SELECT role,content,created_at FROM messages WHERE conversation_id=? ORDER BY created_at")
        .bind(convoMatch[1]).all();
      return respond(req,env,{conversation:c,messages:m.results});
    }

    if (path === "/api/chat" && req.method === "POST") {
      const b=await body(req), cid=String(b.conversationId||"");
      if (!cid || typeof b.message!=="string" || !b.message.trim()) return respond(req,env,{error:"Conversation and message required"},400);
      const convo=await env.DB.prepare("SELECT id FROM conversations WHERE id=?").bind(cid).first();
      if (!convo) return respond(req,env,{error:"Conversation not found"},404);
      const stamp=now();
      await env.DB.prepare("INSERT INTO messages (id,conversation_id,role,content,created_at) VALUES (?,?,?,?,?)")
        .bind(id(),cid,"user",b.message.slice(0,12000),stamp).run();
      if (!(await providerReady(env))) {
        return respond(req,env,{error:"NO_VERIFIED_FREE_PROVIDER",message:"Your message is saved. AI is paused until an eligible free provider is configured. No paid provider was called."},503);
      }
      const history=await env.DB.prepare("SELECT role,content FROM messages WHERE conversation_id=? ORDER BY created_at DESC LIMIT 20")
        .bind(cid).all();
      const msgs=[{role:"system",content:"You are Rahat DeSecret, a careful AI assistant inside a private owner workspace. Be honest about uncertainty. Never claim an external action was completed unless it was actually performed."},
        ...history.results.reverse().map(x=>({role:x.role,content:x.content}))];
      try {
        const answer=await callModel(env,msgs), t=now();
        await env.DB.prepare("INSERT INTO messages (id,conversation_id,role,content,created_at) VALUES (?,?,?,?,?)")
          .bind(id(),cid,"assistant",answer,t).run();
        await env.DB.prepare("UPDATE conversations SET updated_at=? WHERE id=?").bind(t,cid).run();
        return respond(req,env,{answer});
      } catch(e) {
        const msg=e.message==="NO_VERIFIED_FREE_PROVIDER" ? "No verified free provider configured." :
          e.message==="FREE_PROVIDER_QUOTA_OR_ACCESS_BLOCKED" ? "Free provider quota/access blocked. Work paused; no paid fallback." : "Provider request failed; no paid fallback was attempted.";
        await audit(env,"model_call_paused",e.message);
        return respond(req,env,{error:e.message,message:msg},503);
      }
    }

    if (path === "/api/tasks" && req.method === "GET") {
      const r=await env.DB.prepare("SELECT * FROM tasks ORDER BY created_at DESC LIMIT 100").all();
      return respond(req,env,{tasks:r.results});
    }
    if (path === "/api/tasks" && req.method === "POST") {
      const b=await body(req);
      if (!b.title) return respond(req,env,{error:"Task title required"},400);
      const t={id:id(),project_id:b.projectId||null,agent_id:b.agentId||null,title:String(b.title).slice(0,160),
        details:String(b.details||"").slice(0,5000),status:"queued",requires_approval:1,created_at:now(),updated_at:now()};
      await env.DB.prepare("INSERT INTO tasks (id,project_id,agent_id,title,details,status,requires_approval,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)")
        .bind(t.id,t.project_id,t.agent_id,t.title,t.details,t.status,t.requires_approval,t.created_at,t.updated_at).run();
      await audit(env,"task_queued",t.title);
      return respond(req,env,{task:t},201);
    }

    if (path === "/api/memory" && req.method === "GET") {
      const r=await env.DB.prepare("SELECT * FROM memory ORDER BY created_at DESC LIMIT 100").all();
      return respond(req,env,{items:r.results});
    }
    if (path === "/api/memory" && req.method === "POST") {
      const b=await body(req);
      if (!b.content) return respond(req,env,{error:"Memory content required"},400);
      const m={id:id(),scope:"owner",content:String(b.content).slice(0,5000),created_at:now()};
      await env.DB.prepare("INSERT INTO memory (id,scope,content,created_at) VALUES (?,?,?,?)").bind(m.id,m.scope,m.content,m.created_at).run();
      return respond(req,env,{item:m},201);
    }

    return respond(req,env,{error:"Not found"},404);
  }
};
