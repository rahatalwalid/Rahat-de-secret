# Rahat DeSecret — Foundation v0.1

A mobile-first, owner-only AI workspace starter. It is deliberately **model-independent**:
agent identity, conversations, projects and tasks live in D1, not inside any one model.

## Included

- Owner-only login (no public signup)
- Cloudflare Worker backend + D1 schema
- Mobile-first browser dashboard
- Conversation persistence
- Agent profile creation/listing
- Project creation/listing
- Strict free-only provider gate
- OpenAI-compatible chat-completions adapter
- No provider is enabled by default; no paid fallback exists

## Important truth about "free"

A provider's free quota, age eligibility, regional availability and terms can change.
This starter does not claim any provider is permanently free or available to every account.
Only configure a provider after checking its current terms and confirming you are eligible.
Never enter a fake birth date or bypass age restrictions. If a provider requires an adult,
ask a parent/guardian to help only if its terms explicitly allow that arrangement.

## Deployment overview

You need:
1. A Cloudflare account that you are allowed to use under its current age/guardian terms.
2. A Cloudflare Worker and D1 database.
3. A strong owner password and random session secret.
4. An eligible AI provider account/key (optional until you want AI replies).

### 1. Create the D1 database

From Cloudflare dashboard, create a D1 database named `rahat-desecret-db`.
Run `worker/schema.sql` in its console.

### 2. Create the Worker

Create a Worker named `rahat-desecret-api`.
Paste `worker/src/index.js` into the Worker editor, or deploy it with Wrangler.
Bind the D1 database as `DB`.

Set Worker secrets:
- `OWNER_PASSWORD`: a long unique password (never reuse your email password)
- `SESSION_SECRET`: a random secret of at least 32 characters

Set variables:
- `APP_ORIGIN`: your deployed Pages/Worker origin, e.g. `https://your-site.pages.dev`
- `FREE_ONLY`: `true`

### 3. Deploy the app (same-origin)

The Worker serves both the API and the `public/` frontend. This keeps the login cookie
same-origin and avoids fragile cross-site cookie behavior.

From the `worker/` directory, replace the D1 `database_id` in `wrangler.toml`, then deploy
with Wrangler (`npx wrangler deploy`). The assets binding points to `../public`.

### 4. Configure an AI provider (optional)

In Worker variables/secrets, set:
- `AI_BASE_URL`: provider's documented OpenAI-compatible base URL
- `AI_MODEL`: exact model ID available to your account
- `AI_API_KEY`: provider key (secret)
- `AI_PROVIDER_NAME`: provider label
- `AI_FREE_VERIFIED`: `true` only after checking current terms and your eligibility

The backend refuses model calls unless **all** are configured and `AI_FREE_VERIFIED=true`.
If quota/rate limit is reached, the request fails closed. There is no paid fallback.
Do not put keys in `public/app.js`, HTML, browser storage, or screenshots.

For the same-origin deployment, leave `public/config.js` as supplied (`API_BASE: ""`).
Open the Worker URL to use the app. If you later move the frontend to a separate domain,
add a same-origin proxy rather than weakening cookie security.

## Current scope / next build phase

This is a foundation, not a finished autonomous company. The next phase should add:
- durable task queue + scheduled worker
- approval gates for external actions
- agent-to-agent delegation and message bus
- encrypted provider registry UI
- richer memory retrieval and search
- audit log and per-agent permissions
- image/video provider adapters (separate capability routes)

Do not give agents unrestricted access to money, accounts, publishing, or destructive actions.
Keep human approval for external side effects.
